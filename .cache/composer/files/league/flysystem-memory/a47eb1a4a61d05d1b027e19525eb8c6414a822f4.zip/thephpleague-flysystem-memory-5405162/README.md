## Sub-split of Flysystem for in-memory file storage.

> ⚠️ this is a sub-split, for pull requests and issues, visit: https://github.com/thephpleague/flysystem

```bash
composer require league/flysystem-memory
```

View the [documentation](https://flysystem.thephpleague.com/v2/docs/adapter/in-memory/).
